import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;




public class Home extends JFrame implements ActionListener{
	
	JFrame frame = new JFrame();
	JPanel toppanel = new JPanel();
	JPanel mainpanel = new JPanel();
	JButton mobile_btn, accessories_btn;
	

	
	
	
	public Home()
	{
		JLabel mainlabel = new JLabel();
		ImageIcon mobileshopee = new ImageIcon("anonymousMS.jpg");
		Image img = mobileshopee.getImage();
		Image newimg = img.getScaledInstance(1000, 160, java.awt.Image.SCALE_SMOOTH);
		mobileshopee = new ImageIcon(newimg);
		mainlabel.setIcon(mobileshopee);
		mainlabel.setBounds(200,0,1500,200);
		
		
		//********************* mainpanel ****************
		
		Color mainpanelcolor = new Color(99, 110, 114);
		mainpanel.setBackground(mainpanelcolor);
		mainpanel.setBounds(0, 200, 1400, 600);
		mainpanel.setLayout(null);
		
		
		// ******************** Button ********************
		mobile_btn = new JButton("Mobile Brands");
		mobile_btn.setBounds(450, 160, 200, 30);
		mobile_btn.setActionCommand("brands");
		mobile_btn.addActionListener(this);
		
		accessories_btn = new JButton("Mobile Accessories");
		accessories_btn.setBounds(700, 160, 200, 30);
		accessories_btn.setActionCommand("accessories");
		accessories_btn.addActionListener(this);
		
		
		
		
		
		//Add Frame
		frame.add(mobile_btn);
		frame.add(accessories_btn);
		frame.add(mainlabel);
		frame.add(mainpanel);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
	}
	
	public void mobileBrands()
	{
		//Panel
		
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		JPanel panel5 = new JPanel();
		JPanel panel6 = new JPanel();
		JPanel panel7 = new JPanel();
		JPanel panel8 = new JPanel();
		JPanel panel9 = new JPanel();
		JPanel panel10 = new JPanel();
		
		//JLabel
		
		JLabel mi_label = new JLabel();
		JLabel vivo_label = new JLabel();
		JLabel iphone_label = new JLabel();
		JLabel samsung_label = new JLabel();
		JLabel oppo_label = new JLabel();
		JLabel nokia_label = new JLabel();
		JLabel lenovo_label = new JLabel();
		JLabel moto_label = new JLabel();
		JLabel asus_label = new JLabel();
		JLabel honor_label = new JLabel();
		

		
		//panel1
		
		
		panel1.setLayout(null);
		
		Color panel1color = new Color(255, 234, 167);
		panel1.setBackground(java.awt.Color.white);
		panel1.setBounds(50, 50, 200, 200);
		
		ImageIcon mi = new ImageIcon("mi.png");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		mi_label.setIcon(mi);
		mi_label.setBounds(50,50,100,100);
		mi_label.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				
			
				new mi();
				
			}

		});		
		
		
		
		//panel2
		panel2.setLayout(null);
		panel2.setBackground(java.awt.Color.white);
		panel2.setBounds(300, 50, 200, 200);
		
		ImageIcon vivo = new ImageIcon("vivo.png");
		img = vivo.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		vivo = new ImageIcon(newimg);
		vivo_label.setIcon(vivo);
		vivo_label.setBounds(25, 50, 150, 100);
		vivo_label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new vivo();
			}
		});

		
		//panel3
		panel3.setLayout(null);
		
		panel3.setBackground(java.awt.Color.white);
		panel3.setBounds(550, 50, 200, 200);
		
		ImageIcon iphone = new ImageIcon("iphone.jpg");
		img = iphone.getImage();
		newimg = img.getScaledInstance(183, 150, java.awt.Image.SCALE_SMOOTH);
		iphone = new ImageIcon(newimg);
		iphone_label.setIcon(iphone);
		iphone_label.setBounds(0, 50, 300, 100);
		iphone_label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new iphone();
			}
		});
		
		//panel4
		panel4.setLayout(null);
		
		panel4.setBackground(java.awt.Color.white);
		panel4.setBounds(800, 50, 200, 200);
		
		ImageIcon samsung = new ImageIcon("samsung.png");
		img = samsung.getImage();
		newimg = img.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
		samsung = new ImageIcon(newimg);
		samsung_label.setIcon(samsung);
		samsung_label.setBounds(0, 0, 300, 200);
		samsung_label.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				new samsung();
			}
			
		});
		
		
		//panel5
		panel5.setLayout(null);
		panel5.setBackground(java.awt.Color.white);
		panel5.setBounds(1050, 50, 200, 200);
		
		ImageIcon oppo = new ImageIcon("oppo.jpg");
		img = oppo.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		oppo = new ImageIcon(newimg);
		oppo_label.setIcon(oppo);
		oppo_label.setBounds(27, 50, 200, 100);
		
		//panel6
		panel6.setLayout(null);
		
		panel6.setBackground(java.awt.Color.white);
		panel6.setBounds(50, 300, 200, 200);
		
		ImageIcon nokia = new ImageIcon("nokia.png");
		img = nokia.getImage();
		newimg = img.getScaledInstance(200, 150, java.awt.Image.SCALE_SMOOTH);
		nokia = new ImageIcon(newimg);
		nokia_label.setIcon(nokia);
		nokia_label.setBounds(0, 30, 200, 150);
		
		//panel7
		panel7.setLayout(null);
		
		panel7.setBackground(java.awt.Color.white);
		panel7.setBounds(300, 300, 200, 200);
		
		ImageIcon lenovo = new ImageIcon("lenovo.jpg");
		img = lenovo.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		lenovo = new ImageIcon(newimg);
		lenovo_label.setIcon(lenovo);
		lenovo_label.setBounds(27, 50, 200, 100);
		
		//panel8
		panel8.setLayout(null);
		panel8.setBackground(java.awt.Color.white);
		panel8.setBounds(550, 300, 200, 200);
		
		ImageIcon moto = new ImageIcon("motorola.png");
		img = moto.getImage();
		newimg = img.getScaledInstance(200, 150, java.awt.Image.SCALE_SMOOTH);
		moto = new ImageIcon(newimg);
		moto_label.setIcon(moto);
		moto_label.setBounds(0, 0, 300, 200);
		
		//panel9
		panel9.setLayout(null);
		panel9.setBackground(java.awt.Color.white);
		panel9.setBounds(800, 300, 200, 200);
		
		ImageIcon asus = new ImageIcon("asus.jpeg");
		img = asus.getImage();
		newimg = img.getScaledInstance(150, 50, java.awt.Image.SCALE_SMOOTH);
		asus = new ImageIcon(newimg);
		asus_label.setIcon(asus);
		asus_label.setBounds(20, 30, 200, 150);
		
		//panel10
		panel10.setLayout(null);
		panel10.setBackground(java.awt.Color.white);
		panel10.setBounds(1050, 300, 200, 200);
		
		ImageIcon honor = new ImageIcon("honor.jpg");
		img = honor.getImage();
		newimg = img.getScaledInstance(150, 50, java.awt.Image.SCALE_SMOOTH);
		honor = new ImageIcon(newimg);
		honor_label.setIcon(honor);
		honor_label.setBounds(30, 30, 200, 150);
		
		//
		mainpanel.add(panel1);
		mainpanel.add(panel2);
		mainpanel.add(panel3);
		mainpanel.add(panel4);
		mainpanel.add(panel5);
		mainpanel.add(panel6);
		mainpanel.add(panel7);
		mainpanel.add(panel8);
		mainpanel.add(panel9);
		mainpanel.add(panel10);
		
		
		panel1.add(mi_label);
		panel2.add(vivo_label);
		panel3.add(iphone_label);
		panel4.add(samsung_label);
		panel5.add(oppo_label);
		panel6.add(nokia_label);
		panel7.add(lenovo_label);
		panel8.add(moto_label);
		panel9.add(asus_label);
		panel10.add(honor_label);
	}
	
	public void mobileAccessories()
	{
		//Panel
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		JPanel panel5 = new JPanel();
		JPanel panel6 = new JPanel();
		JPanel panel7 = new JPanel();
		JPanel panel8 = new JPanel();
		JPanel panel9 = new JPanel();
		JPanel panel10 = new JPanel();
		
		//JLabel
		
		JLabel cover = new JLabel();
		JLabel power_bank = new JLabel();
		JLabel mobile_battery = new JLabel();
		JLabel memory_card = new JLabel();
		JLabel earphone = new JLabel();
		JLabel mobile_charger = new JLabel();
		JLabel OTG_adaptor = new JLabel();
		JLabel bluetooth = new JLabel();
		JLabel headphone = new JLabel();
		JLabel screengaurd = new JLabel();
		
		

		
		
		//panel1
		JLabel text1 = new JLabel();
		panel1.setLayout(null);
		
		Color panel1color = new Color(255, 234, 167);
		panel1.setBackground(java.awt.Color.white);
		panel1.setBounds(50, 50, 200, 200);
		
		ImageIcon cov = new ImageIcon("cover.jpeg");
		Image img = cov.getImage();
		Image newimg = img.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
		cov = new ImageIcon(newimg);
		cover.setIcon(cov);
		cover.setBounds(50,50,100,100);
		text1.setText("Mobile Covers");
		panel1.add(text1);
		text1.setBounds(50,150,100,50);
		
		
		//panel2
		JLabel text2 = new JLabel();
		panel2.setLayout(null);
		panel2.setBackground(java.awt.Color.white);
		panel2.setBounds(300, 50, 200, 200);
		
		ImageIcon power = new ImageIcon("powerbank.jpg");
		img = power.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		power = new ImageIcon(newimg);
		power_bank.setIcon(power);
		power_bank.setBounds(25, 50, 150, 100);
		text2.setText("Power Bank");
		panel2.add(text2);
		text2.setBounds(50,150,100,50);

		
		//panel3
		JLabel text3 = new JLabel();
		panel3.setLayout(null);
		
		panel3.setBackground(java.awt.Color.white);
		panel3.setBounds(550, 50, 200, 200);
		
		ImageIcon memory = new ImageIcon("memorycard.jpg");
		img = memory.getImage();
		newimg = img.getScaledInstance(183, 150, java.awt.Image.SCALE_SMOOTH);
		memory = new ImageIcon(newimg);
		memory_card.setIcon(memory);
		memory_card.setBounds(0, 50, 300, 100);
		text3.setText("Memory Card");
		panel3.add(text3);
		text3.setBounds(50,150,100,50);
		
		//panel4
		JLabel text4 = new JLabel();
		panel4.setLayout(null);
		
		panel4.setBackground(java.awt.Color.white);
		panel4.setBounds(800, 50, 200, 200);
		
		ImageIcon ear = new ImageIcon("earphone.jpg");
		img = ear.getImage();
		newimg = img.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
		ear = new ImageIcon(newimg);
		earphone.setIcon(ear);
		earphone.setBounds(50, 0, 300, 200);
		text4.setText("Earphone");
		panel4.add(text4);
		text4.setBounds(50,150,100,50);
		
		//panel5
		JLabel text5 = new JLabel();
		panel5.setLayout(null);
		panel5.setBackground(java.awt.Color.white);
		panel5.setBounds(1050, 50, 200, 200);
		
		ImageIcon charger = new ImageIcon("mobilecharger.jpg");
		img = charger.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		charger = new ImageIcon(newimg);
		mobile_charger.setIcon(charger);
		mobile_charger.setBounds(27, 50, 200, 100);
		text5.setText("Chargers");
		panel5.add(text5);
		text5.setBounds(50,150,100,50);
		
		//panel6
		JLabel text6 = new JLabel();
		panel6.setLayout(null);
		
		panel6.setBackground(java.awt.Color.white);
		panel6.setBounds(50, 300, 200, 200);
		
		ImageIcon otg = new ImageIcon("otgadaptor.jpg");
		img = otg.getImage();
		newimg = img.getScaledInstance(200, 150, java.awt.Image.SCALE_SMOOTH);
		otg = new ImageIcon(newimg);
		OTG_adaptor.setIcon(otg);
		OTG_adaptor.setBounds(0, 30, 200, 150);
		text6.setText("OTG Adaptors");
		panel6.add(text6);
		text6.setBounds(50,150,100,50);
		
		//panel7
		JLabel text7 = new JLabel();
		panel7.setLayout(null);
		
		panel7.setBackground(java.awt.Color.white);
		panel7.setBounds(300, 300, 200, 200);
		
		ImageIcon blue = new ImageIcon("bluetooth.jpeg");
		img = blue.getImage();
		newimg = img.getScaledInstance(150, 100, java.awt.Image.SCALE_SMOOTH);
		blue = new ImageIcon(newimg);
		bluetooth.setIcon(blue);
		bluetooth.setBounds(27, 50, 200, 100);
		text7.setText("Bluetooth");
		panel7.add(text7);
		text7.setBounds(50,150,100,50);
		
		//panel8
		JLabel text8 = new JLabel();
		panel8.setLayout(null);
		panel8.setBackground(java.awt.Color.white);
		panel8.setBounds(550, 300, 200, 200);
		
		ImageIcon head = new ImageIcon("headphone.jpg");
		img = head.getImage();
		newimg = img.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
		head = new ImageIcon(newimg);
		headphone.setIcon(head);
		headphone.setBounds(30, 0, 300, 200);
		text8.setText("Headphones");
		panel8.add(text8);
		text8.setBounds(50,155,100,50);
		
		//panel9
		JLabel text9 = new JLabel();
		panel9.setLayout(null);
		panel9.setBackground(java.awt.Color.white);
		panel9.setBounds(800, 300, 200, 200);
		
		ImageIcon screen = new ImageIcon("screengaurd.JPG");
		img = screen.getImage();
		newimg = img.getScaledInstance(100, 125, java.awt.Image.SCALE_SMOOTH);
		screen = new ImageIcon(newimg);
		screengaurd.setIcon(screen);
		screengaurd.setBounds(50, 10, 200, 150);
		text9.setText("Screenguard");
		panel9.add(text9);
		text9.setBounds(50,150,100,50);
		
		//panel10
		JLabel text10 = new JLabel();
		panel10.setLayout(null);
		panel10.setBackground(java.awt.Color.white);
		panel10.setBounds(1050, 300, 200, 200);
		
		ImageIcon battry = new ImageIcon("mobilebattery.jpg");
		img = battry.getImage();
		newimg = img.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
		battry = new ImageIcon(newimg);
		mobile_battery.setIcon(battry);
		mobile_battery.setBounds(5, 30, 200, 150);
		text10.setText("Mobile Battery");
		panel10.add(text10);
		text10.setBounds(50,150,100,50);
		
		//
		mainpanel.add(panel1);
		mainpanel.add(panel2);
		mainpanel.add(panel3);
		mainpanel.add(panel4);
		mainpanel.add(panel5);
		mainpanel.add(panel6);
		mainpanel.add(panel7);
		mainpanel.add(panel8);
		mainpanel.add(panel9);
		mainpanel.add(panel10);
		
		
		
		panel1.add(cover);
		panel2.add(power_bank);
		panel3.add(memory_card);
		panel4.add(earphone);
		panel5.add(mobile_charger);
		panel6.add(OTG_adaptor);
		panel7.add(bluetooth);
		panel8.add(headphone);
		panel9.add(screengaurd);
		panel10.add(mobile_battery);
		
		
	}

	public static void main(String[] args) {
		
		 SwingUtilities.invokeLater(new Runnable() {
	            @Override
	            public void run() {
	             new Home();
	            }
	        });

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Home obj = new Home();
		String cmd = e.getActionCommand();
		if(cmd.equals("brands"))
		{
			this.dispose();
			obj.mobileBrands();
			//frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		}
		else if(cmd.equals("accessories"))
		{
			this.dispose();
			obj.mobileAccessories();
			//frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
			
		}
		
	}

}
