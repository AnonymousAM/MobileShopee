
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.io.UnsupportedEncodingException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class iphone {
	
	JPanel mainpanel  = new JPanel();
	Color mainpanelcolor = new Color(99, 110, 114);
	JFrame frame = new JFrame();
	
	

	
	//Panel
	
	
	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
	JPanel panel3 = new JPanel();
	JPanel panel4 = new JPanel();
	JPanel panel5 = new JPanel();
	JPanel panel6 = new JPanel();
	JPanel panel7 = new JPanel();
	JPanel panel8 = new JPanel();
	JPanel panel9 = new JPanel();
	JPanel panel10 = new JPanel();
	
	//JLabel
	
	JLabel iphone_label = new JLabel();
	JLabel iphone_label2 = new JLabel();
	JLabel iphone_label3 = new JLabel();
	JLabel iphone_label4 = new JLabel();
	JLabel mi_label5 = new JLabel();
	JLabel nokia_label = new JLabel();
	JLabel lenovo_label = new JLabel();
	JLabel moto_label = new JLabel();
	JLabel asus_label = new JLabel();
	JLabel honor_label = new JLabel();
	

	
	public iphone()
	{
		JFrame frame = new JFrame();
		frame.setLayout(null);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		
		frame.add(mainpanel);
		
		MainPanel();
		Panel1();
		Panel2();
		Panel3();
		Panel4();
		Panel5();
	}
	
	public void MainPanel()
	{
		JPanel panel = new JPanel();
		mainpanel.setBackground(mainpanelcolor);
		mainpanel.setBounds(0, 200, 1400, 600);
		mainpanel.setLayout(null);
		
		
		
		
		mainpanel.add(panel1);
		mainpanel.add(panel2);
		mainpanel.add(panel3);
		mainpanel.add(panel4);
		mainpanel.add(panel5);
	}
	
	public void Panel1()
	{
		JLabel text = new JLabel();
		JLabel price = new JLabel();
		
		 String string = "\u20B9";
		    byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		panel1.setLayout(null);
		panel1.setBackground(java.awt.Color.white);
		panel1.setBounds(70, 50, 250, 400);
		
		ImageIcon mi = new ImageIcon("iphonexr.jpeg");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(150, 300, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		iphone_label.setIcon(mi);
		iphone_label.setBounds(50,20,200,300);
		text.setText("Apple iPhone XR");
		text.setFont(new Font(text.getName(), Font.BOLD, 15)); 
		text.setBounds(60, 330, 200, 20);
		
		price.setText(string+"76,900");
		price.setFont(new Font(text.getName(), Font.BOLD, 18)); 
		price.setBounds(90, 355, 100, 20);
		
		panel1.add(iphone_label);
		panel1.add(text);
		panel1.add(price);
	}
	
	
	public void Panel2()
	{
		JLabel text = new JLabel();
		JLabel price = new JLabel();
		
		 String string = "\u20B9";
		    byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		panel2.setLayout(null);
		panel2.setBackground(java.awt.Color.white);
		panel2.setBounds(390, 50, 250, 400);
		
		ImageIcon mi = new ImageIcon("iphonexs.jpeg");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(150, 300, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		iphone_label2.setIcon(mi);
		iphone_label2.setBounds(50,20,200,300);
		text.setText("Apple iPhone XS");
		text.setFont(new Font(text.getName(), Font.BOLD, 15)); 
		text.setBounds(60, 330, 200, 20);
		
		price.setText(string+"99,900");
		price.setFont(new Font(text.getName(), Font.BOLD, 18)); 
		price.setBounds(90, 355, 100, 20);
		
		panel2.add(iphone_label2);
		panel2.add(text);
		panel2.add(price);
	}

	public void Panel3()
	{
		JLabel text = new JLabel();
		JLabel price = new JLabel();
		
		 String string = "\u20B9";
		    byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		panel3.setLayout(null);
		panel3.setBackground(java.awt.Color.white);
		panel3.setBounds(710, 50, 250, 400);
		
		ImageIcon mi = new ImageIcon("iphone7.jpeg");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(150, 300, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		iphone_label3.setIcon(mi);
		iphone_label3.setBounds(50,20,200,300);
		text.setText("Apple iPhone 7");
		text.setFont(new Font(text.getName(), Font.BOLD, 15)); 
		text.setBounds(65, 330, 200, 20);
		
		price.setText(string+"52,490");
		price.setFont(new Font(text.getName(), Font.BOLD, 18)); 
		price.setBounds(90, 355, 100, 20);
		
		panel3.add(iphone_label3);
		panel3.add(text);
		panel3.add(price);
	}
	
	public void Panel4()
	{
		JLabel text = new JLabel();
		JLabel price = new JLabel();
		
		 String string = "\u20B9";
		    byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		panel4.setLayout(null);
		panel4.setBackground(java.awt.Color.white);
		panel4.setBounds(1030, 50, 250, 400);
		
		ImageIcon mi = new ImageIcon("iphone8.jpeg");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(150, 300, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		iphone_label4.setIcon(mi);
		iphone_label4.setBounds(50,20,200,300);
		text.setText("Apple iPhone 8");
		text.setFont(new Font(text.getName(), Font.BOLD, 15)); 
		text.setBounds(60, 330, 200, 20);
		
		price.setText(string+"58,999");
		price.setFont(new Font(text.getName(), Font.BOLD, 18)); 
		price.setBounds(90, 355, 100, 20);
		
		panel4.add(iphone_label4);
		panel4.add(text);
		panel4.add(price);
	}
	
	public void Panel5()
	{
		JLabel text = new JLabel();
		JLabel price = new JLabel();
		
		 String string = "\u20B9";
		    byte[] utf8;
			try {
				utf8 = string.getBytes("UTF-8");
				string = new String(utf8, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    
		panel5.setLayout(null);
		panel5.setBackground(java.awt.Color.white);
		panel5.setBounds(70, 500, 250, 400);
		
		ImageIcon mi = new ImageIcon("minote5.jpeg");
		Image img = mi.getImage();
		Image newimg = img.getScaledInstance(150, 300, java.awt.Image.SCALE_SMOOTH);
		mi = new ImageIcon(newimg);
		mi_label5.setIcon(mi);
		mi_label5.setBounds(50,20,200,300);
		text.setText("Redmi Note 5");
		text.setFont(new Font(text.getName(), Font.BOLD, 15)); 
		text.setBounds(70, 330, 200, 20);
		
		price.setText(string+"10,985");
		price.setFont(new Font(text.getName(), Font.BOLD, 18)); 
		price.setBounds(90, 355, 100, 20);
		
		panel5.add(mi_label5);
		panel5.add(text);
		panel5.add(price);
	}
}

